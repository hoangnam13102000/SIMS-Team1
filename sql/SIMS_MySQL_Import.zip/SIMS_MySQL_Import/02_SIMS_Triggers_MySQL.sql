/* ============================================================
   SIMS - Triggers MySQL
   LUU Y: MySQL KHONG cho trigger UPDATE cung bang dang INSERT
   (loi #1442). Cac ma PRD_/BAT_/ORD_... duoc gan bang procedure
   goi sau INSERT, hoac app Java. Seed (03) da xu ly InventoryBatch
   + Stock thu cong.

   Chay file nay SAU 01_Schema. Co the chay lai sau 03_SampleData.
   ============================================================ */
USE SIMS_DB;

DROP PROCEDURE IF EXISTS sp_AssignProductCode;
DROP PROCEDURE IF EXISTS sp_AssignBatchCode;
DROP PROCEDURE IF EXISTS sp_AssignOrderCode;
DROP PROCEDURE IF EXISTS sp_AssignDisposalCode;
DROP PROCEDURE IF EXISTS sp_AssignSupplierReturnCode;
DROP PROCEDURE IF EXISTS sp_BackfillAllCodes;

DELIMITER //

CREATE PROCEDURE sp_AssignProductCode(IN p_id INT)
BEGIN
    UPDATE Products
    SET ProductCode = CONCAT('PRD_', LPAD(p_id, 4, '0'))
    WHERE ProductID = p_id AND (ProductCode IS NULL OR ProductCode = '');
END //

CREATE PROCEDURE sp_AssignBatchCode(IN p_id INT)
BEGIN
    UPDATE InventoryBatch
    SET BatchCode = CONCAT('BAT_', LPAD(p_id, 4, '0'))
    WHERE BatchID = p_id AND (BatchCode IS NULL OR BatchCode = '');
END //

CREATE PROCEDURE sp_AssignOrderCode(IN p_id INT)
BEGIN
    UPDATE Orders
    SET OrderCode = CONCAT('ORD_', LPAD(p_id, 4, '0'))
    WHERE OrderID = p_id AND (OrderCode IS NULL OR OrderCode = '');
END //

CREATE PROCEDURE sp_AssignDisposalCode(IN p_id INT)
BEGIN
    UPDATE StockDisposals
    SET DisposalCode = CONCAT('DIS_', LPAD(p_id, 4, '0'))
    WHERE DisposalID = p_id AND (DisposalCode IS NULL OR DisposalCode = '');
END //

CREATE PROCEDURE sp_AssignSupplierReturnCode(IN p_id INT)
BEGIN
    UPDATE SupplierReturns
    SET SupplierReturnCode = CONCAT('SR_', LPAD(p_id, 4, '0'))
    WHERE SupplierReturnID = p_id AND (SupplierReturnCode IS NULL OR SupplierReturnCode = '');
END //

-- Gan ma cho toan bo ban ghi dang NULL (chay sau seed)
CREATE PROCEDURE sp_BackfillAllCodes()
BEGIN
    UPDATE Products
    SET ProductCode = CONCAT('PRD_', LPAD(ProductID, 4, '0'))
    WHERE ProductCode IS NULL OR ProductCode = '';

    UPDATE InventoryBatch
    SET BatchCode = CONCAT('BAT_', LPAD(BatchID, 4, '0'))
    WHERE BatchCode IS NULL OR BatchCode = '';

    UPDATE Orders
    SET OrderCode = CONCAT('ORD_', LPAD(OrderID, 4, '0'))
    WHERE OrderCode IS NULL OR OrderCode = '';

    UPDATE StockDisposals
    SET DisposalCode = CONCAT('DIS_', LPAD(DisposalID, 4, '0'))
    WHERE DisposalCode IS NULL OR DisposalCode = '';

    UPDATE SupplierReturns
    SET SupplierReturnCode = CONCAT('SR_', LPAD(SupplierReturnID, 4, '0'))
    WHERE SupplierReturnCode IS NULL OR SupplierReturnCode = '';
END //

DELIMITER ;

-- Tu dong backfill neu da co du lieu
CALL sp_BackfillAllCodes();
