SIMS MySQL - Goi import
========================

Thu tu chay (phpMyAdmin Import hoac mysql CLI):

  1. 01_SIMS_Schema_MySQL.sql     -> tao DB + bang
  2. 02_SIMS_Triggers_MySQL.sql   -> trigger ma hoa (ProductCode, BatchCode...)
  3. 03_SIMS_SampleData_MySQL.sql -> du lieu mau day du (hoac 00_RBAC neu chi can admin)

CLI:
  mysql -u root -p < 01_SIMS_Schema_MySQL.sql
  mysql -u root -p < 02_SIMS_Triggers_MySQL.sql
  mysql -u root -p < 03_SIMS_SampleData_MySQL.sql

Tai khoan demo (password: 123456):
  admin, salesmgr, invmgr, staff01, staff02
  lan.nguyen, hung.tran, mai.pham, duc.le, customer1

Luu y:
  - File 03 se TRUNCATE toan bo bang roi insert lai (re-run an toan).
  - File 03 DROP trigger tren Products truoc INSERT de tranh loi #1442;
    sau do hay chay lai 02_SIMS_Triggers_MySQL.sql neu can.
  - Trigger FEFO / cong Stock khi ban hang / Return: seed da xu ly phan
    InventoryBatch thu cong; logic day du can convert them tu Trigger_SIMS.sql.
